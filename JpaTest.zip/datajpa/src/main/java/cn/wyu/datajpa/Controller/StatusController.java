package cn.wyu.datajpa.Controller;

import cn.wyu.datajpa.pojo.Status;
import cn.wyu.datajpa.service.StatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RestController
public class StatusController {
    @Autowired
    private StatusService statusService;

    /**
     * 查询所有
     * http://localhost:8853/list
     * @return
     */
    @GetMapping("/list")
    public List<Status> findAll() {
        return statusService.findAll();
    }

    /**
     * 查询某作者的博文
     * http://localhost:8853/author/ben
     * @param author
     * @return
     */
    @GetMapping("/author/{author}")
    public List<Status> findByAuthor(@PathVariable String author) {
        return statusService.findByAuthor(author);
    }

    /**
     * 查找点赞数大于某值的博文
     * http://localhost:8853/likes/5
     * @param likes
     * @return
     */
    @GetMapping("/likes/{likes}")
    public List<Status> findByLikesGreaterThan(@PathVariable int likes) {
        return statusService.findByLikesGreaterThan(likes);
    }

    /**
     * 查找包含某关键字的博文
     * http://localhost:8853/keyword/second
     * @param keyword
     * @return
     */
    @GetMapping("/keyword/{keyword}")
    public List<Status> findByContentContainingIgnoreCase(@PathVariable String keyword) {
        return statusService.findByContentContainingIgnoreCase(keyword);
    }

    /**
     * 查找某作者在某时间前发布的博文，并按发布时间升序排序
     * http://localhost:8853/createtime?author=peter&timestamp=2020-07-05%2010:10:01
     * @param author
     * @param timestamp
     * @return
     */
    @GetMapping("/createtime")
    public List<Status> findByAuthorAndCreateTimeBeforeOrderByCreateTime(@RequestParam("author") String author,@RequestParam("timestamp")Timestamp timestamp) {
        //timestamp.valueOf("2020-07-03 10:10:01");
        return statusService.findByAuthorAndCreateTimeBeforeOrderByCreateTime(author, timestamp);
    }

    /**
     * 查找某月份发布的博文
     * http://localhost:8853/month/7
     * @param month
     * @return
     */
    @GetMapping("/month/{month}")
    public List<Status> findStatusInMonth(@PathVariable int month) {
        return statusService.findStatusInMonth(month);
    }

    /**
     * 删除某作者的博文
     * @param author
     * @return
     */
    @GetMapping("/delauthor/{author}")
    public Long deleteByAuthor(@PathVariable String author) {
        return statusService.deleteByAuthor(author);
    }
}
