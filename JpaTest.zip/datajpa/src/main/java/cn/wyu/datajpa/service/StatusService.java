package cn.wyu.datajpa.service;

import cn.wyu.datajpa.pojo.Status;

import java.sql.Timestamp;
import java.util.List;

public interface StatusService {
//    List<Status> findByAuthor(String author);
    //查询所有数据
    List<Status> findAll();
    //查询某作者的博文
    List<Status> findByAuthor(String author);

    //查找点赞数大于某值的博文
    List<Status> findByLikesGreaterThan(int likes);

    //查找包含某关键字的博文
    List<Status> findByContentContainingIgnoreCase(String keyword);

    //查找某作者在某时间前发布的博文，并按发布时间升序排序
    List<Status> findByAuthorAndCreateTimeBeforeOrderByCreateTime(String author, Timestamp timestamp);

    //查找某月份发布的博文
    List<Status> findStatusInMonth(int month);

    //删除某作者的博文
    Long deleteByAuthor(String author);
}
