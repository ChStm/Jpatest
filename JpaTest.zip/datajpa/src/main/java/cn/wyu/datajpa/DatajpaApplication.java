package cn.wyu.datajpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatajpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatajpaApplication.class, args);
//        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DatajpaApplication.class);
////        StatusService statusService = context.getBean(StatusService.class);
////
////        statusService.test();
    }

}
