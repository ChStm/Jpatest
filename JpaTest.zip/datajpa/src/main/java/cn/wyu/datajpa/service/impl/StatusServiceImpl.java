package cn.wyu.datajpa.service.impl;

import cn.wyu.datajpa.dao.StatusDao;
import cn.wyu.datajpa.pojo.Status;
import cn.wyu.datajpa.service.StatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Service
public class StatusServiceImpl implements StatusService {

    @Autowired
    private StatusDao statusDao;

    /**
     * 查询所有
     * @return
     */
    @Override
    public List<Status> findAll() {
        return statusDao.findAll();
        //return statusDao.findAll();
    }

    /**
     * 按作者名查找
     * @param author
     * @return
     */
    @Override
    public List<Status> findByAuthor(String author) {
        return statusDao.findByAuthor(author);
    }

    /**
     * 查找点赞数大于某值的博文
     * @param likes
     * @return
     */
    @Override
    public List<Status> findByLikesGreaterThan(int likes) {
        return statusDao.findByLikesGreaterThan(likes);
    }

    /**
     * 查找包含某关键字的博文
     * @param keyword
     * @return
     */
    @Override
    public List<Status> findByContentContainingIgnoreCase(String keyword) {
        return statusDao.findByContentContainingIgnoreCase(keyword);
    }

    /**
     * 查找某作者在某时间前发布的博文，并按发布时间升序排序
     * @param author
     * @param timestamp
     * @return
     */
    @Override
    public List<Status> findByAuthorAndCreateTimeBeforeOrderByCreateTime(String author, Timestamp timestamp) {
        return statusDao.findByAuthorAndCreateTimeBeforeOrderByCreateTime(author, timestamp);
    }

    /**
     * 查找某月份发布的博文
     * @param month
     * @return
     */
    @Override
    public List<Status> findStatusInMonth(int month) {
        return statusDao.findStatusInMonth(month);
    }

    /**
     * 删除某作者的博文
     * @param author
     * @return
     */
    @Override
    public Long deleteByAuthor(String author) {
        return statusDao.deleteByAuthor(author);
    }

}
